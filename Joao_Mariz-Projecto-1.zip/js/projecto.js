var slideIndex = 0;
carousel();
checkCookiesAccepted();

function checkCookiesAccepted() {
  if (sessionStorage.getItem("cookieAccept")) {
    document.querySelector("#telaInit").style.display = "none";
    document.querySelector("body").style.overflow = "auto";
    document.querySelector("body").style.margin = "0px";
  }
}

function loginFunction(userName, passWord) {

  fetch("http://localhost:3000/utilizadores")
      .then(response => {
              return response.json();
      })
    .then(jsonData => {

      for (let user of jsonData) {
        
        if (user.email === userName && user.senha === passWord) {
          document.querySelector("#userLogged").innerHTML = "Bem-vindo(a), " + user.nome + "!";
          document.querySelector("#tela").style.display = "none";
          document.querySelector("#loginButton").style.display = "none"; 
          document.querySelector("#logoutButton").style.display = "block";
          document.querySelector("#loginout").innerHTML = "Logout";
          sessionStorage.setItem("whoIsLoggedId", user.id);
          return;
        }
      }

      document.querySelector(".errorMessage").innerHTML = "Utilizador Inexistente";
      document.querySelector(".errorMessage").style.visibility = "visible";

    });
};


function carousel() {

  var i;
  var x = document.getElementsByClassName("mySlides");

  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none"; 
  }
  slideIndex++;
  if (slideIndex > x.length) {
    slideIndex = 1
  }

  x[slideIndex-1].style.display = "block";

  setTimeout(carousel, 2000); 
}

document.getElementById('magGlassButton')
          .addEventListener('click', function () {
              document.getElementById('pesquisa')
                .classList
                .toggle('active');
              document.querySelector("#pesquisa").focus();
});

let scrollToTop = document.getElementById("upArrow");

window.onscroll = function() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    scrollToTop.style.display = "block";
  } else {
    scrollToTop.style.display = "none";
  }
}

scrollToTop.addEventListener("click", function() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0
});

document.getElementById('loginButton')
  .addEventListener('click', function () {
      document.getElementById('tela').style.display = "block";
      email.focus();
});


document.querySelector("#tela .btFechaTela").addEventListener("click", function() {
  document.querySelector("#tela").style.display="none";
});

function emailValidation(email) {

  var regEx = /\S+@\S+\.\S+/;
  return regEx.test(email);

}

let email=document.querySelector("#eMail");
let senha=document.querySelector("#senha");

document.querySelector(".btValidar").addEventListener("click", function() {
    let emailValue = email.value.trim();
    let pwValue = senha.value.trim();

    if(emailValue === "" && pwValue === "") {
      document.querySelector(".errorMessage").innerHTML = "Os dois campos sao de preenchimento obrigatório";
      document.querySelector(".errorMessage").style.visibility = "visible";
      return;
    }

    if(!emailValidation(emailValue)) {
      document.querySelector(".errorMessage").innerHTML = "O endereço de email é inválido";
      document.querySelector(".errorMessage").style.visibility = "visible";
      return;
    } else {
        document.querySelector(".errorMessage").style.visibility = "hidden";
        loginFunction(emailValue, pwValue);
    }
});

document.querySelector("#telaInit #cookieButton").addEventListener("click", function() {
  document.querySelector("#telaInit").style.display="none";
  document.querySelector("body").style.overflow="auto";
  document.querySelector("body").style.margin="0px";
  sessionStorage.setItem("cookieAccept", "true");
});

document.querySelector("#logoutButton").addEventListener("click", function() {
  sessionStorage.removeItem("whoIsLoggedId");
  document.querySelector("#userLogged").innerHTML ="";
  document.querySelector("#loginButton").style.display = "block"; 
  document.querySelector("#logoutButton").style.display = "none";
  document.querySelector("#loginout").innerHTML = "Login";
});
